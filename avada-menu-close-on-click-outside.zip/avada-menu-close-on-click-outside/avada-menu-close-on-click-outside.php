<?php
/**
 * Plugin Name: Avada Mobile Menu Close on Outside Click
 * Description: Closes the Avada mobile menu when clicking outside of it.
 * Version: 1.0
 * Author: ChatGPT
 */

add_action('wp_footer', function () {
    ?>
    <script>
    document.addEventListener('click', function (event) {
        const body = document.body;
        const isMenuOpen = body.classList.contains('fusion-mobile-menu-active');

        const clickedInsideMenu =
            event.target.closest('.fusion-header') ||
            event.target.closest('.fusion-mobile-nav-holder') ||
            event.target.closest('.fusion-mobile-menu-wrapper');

        if (isMenuOpen && !clickedInsideMenu) {
            const toggle = document.querySelector('.awb-menu__m-toggle');
            if (toggle) toggle.click(); // Simulates real click
        }
    });
    </script>
    <?php
});
